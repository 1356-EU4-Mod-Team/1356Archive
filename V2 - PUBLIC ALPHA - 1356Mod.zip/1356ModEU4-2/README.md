1356 & Barbarossas Throne - A Timeline Extension Mod for Europa Universalis IV A mod for the game Europa Universalis IV that extends the timeline back to the signing of Charles IV's Golden Bull in 1356. We've since merged Barbarossas Throne, a submod for 1356.

This is our workspace, so if you're here congrats! If you have any questions for us please contact us at our Discord or on the Steam Workshop please! If you're a developer glad to have you with us, best of luck on the current work!

Count Flandy, Project Lead.
Workshop Link: https://steamcommunity.com/sharedfiles/filedetails/?id=169289951 PDX Forums Link: https://forum.paradoxplaza.com/forum/index.php?threads/1356-a-timeline-extension-mod-for-euiv.1089290/ Our Discord: https://discord.gg/uzXnRuB
